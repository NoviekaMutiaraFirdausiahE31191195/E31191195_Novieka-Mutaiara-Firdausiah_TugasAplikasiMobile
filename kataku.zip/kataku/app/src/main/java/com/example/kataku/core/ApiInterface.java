package com.example.kataku.core;

import com.example.kataku.model.CekIsFavorit;
import com.example.kataku.model.GetBuku;
import com.example.kataku.model.GetKategoriBuku;
import com.example.kataku.model.Login;
import com.example.kataku.model.Register;
import com.example.kataku.model.TambahHapusFavorit;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("buku_terfavorit.php")
    Call<GetBuku> getTerfavorit();

    @GET("list_kategori.php")
    Call<GetKategoriBuku> getKategoriBuku();

    @GET("list_buku_by_kategori.php")
    Call<GetBuku> getBookByKategori(@Query("nama_kategori") String kategori);

    @GET("list_item_favorit_by_user.php")
    Call<GetBuku> getFavorit(@Query("id_user") int id_user);

    @GET("cek_is_favorit.php")
    Call<CekIsFavorit> checkIsFavorit(@Query("id_produk") int id_produk, @Query("id_user") int id_user);

    @FormUrlEncoded
    @POST("tambah_favorit.php")
    Call<TambahHapusFavorit> tambahFavorit(@Field("id_produk") int id_produk, @Field("id_user") int id_user);

    @GET("hapus_favorit.php")
    Call<TambahHapusFavorit> hapusFavorit(@Query("id_produk") int id_produk, @Query("id_user") int id_user);

    @FormUrlEncoded
    @POST("login.php")
    Call<Login> login(@Field("username") String username, @Field("password") String password);

    @FormUrlEncoded
    @POST("register.php")
    Call<Register> register(@Field("nama") String naman, @Field("username") String username, @Field("password") String password);
}
