package com.example.kataku.model;

import com.google.gson.annotations.SerializedName;

public class Buku {
    @SerializedName("id")
    private int id;
    @SerializedName("nama")
    private String nama;
    @SerializedName("berat")
    private int berat;
    @SerializedName("foto")
    private String foto;
    @SerializedName("deskripsi")
    private String deskripsi;
    @SerializedName("kategori")
    private String kategori;
    @SerializedName("total_favorit")
    private String total_favorit;

    public Buku(int id, String nama, int berat, String foto, String deskripsi, String kategori, String total_favorit) {
        this.id = id;
        this.nama = nama;
        this.berat = berat;
        this.foto = foto;
        this.deskripsi = deskripsi;
        this.kategori = kategori;
        this.total_favorit = total_favorit;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getBerat() {
        return berat;
    }

    public void setBerat(int berat) {
        this.berat = berat;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getTotal_favorit() {
        return total_favorit;
    }

    public void setTotal_favorit(String total_favorit) {
        this.total_favorit = total_favorit;
    }
}
