package com.example.kataku.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetBuku {
    @SerializedName("data")
    private List<Buku> mBuku;

    public List<Buku> getmBuku() {
        return mBuku;
    }

    public void setmBuku(List<Buku> mBuku) {
        this.mBuku = mBuku;
    }
}
