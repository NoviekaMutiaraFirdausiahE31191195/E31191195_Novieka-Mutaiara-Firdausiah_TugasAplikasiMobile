package com.example.kataku.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetKategoriBuku {
    @SerializedName("data")
    private List<KategoriBuku> mKategori;

    public List<KategoriBuku> getmKategori() {
        return mKategori;
    }

    public void setmKategori(List<KategoriBuku> mKategori) {
        this.mKategori = mKategori;
    }
}
