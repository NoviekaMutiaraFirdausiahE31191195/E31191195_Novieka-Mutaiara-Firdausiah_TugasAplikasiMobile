package com.example.kataku.model;

import com.google.gson.annotations.SerializedName;

public class KategoriBuku {
    @SerializedName("id")
    private int id;
    @SerializedName("nama_kategori")
    private String nama_kategori;

    public KategoriBuku(int id, String nama_kategori) {
        this.id = id;
        this.nama_kategori = nama_kategori;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama_kategori() {
        return nama_kategori;
    }

    public void setNama_kategori(String nama_kategori) {
        this.nama_kategori = nama_kategori;
    }
}
