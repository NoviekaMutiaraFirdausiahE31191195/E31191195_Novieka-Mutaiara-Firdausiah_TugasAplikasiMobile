package com.example.kataku.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kataku.R;
import com.example.kataku.core.ApiClient;
import com.example.kataku.core.ApiInterface;
import com.example.kataku.model.Buku;
import com.example.kataku.model.GetBuku;
import com.example.kataku.ui.adapter.BukuAdapter;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BookActivity extends AppCompatActivity {

    private SharedPreferences preferences;
    ApiInterface mApiInterface;
    Intent mData;
    RecyclerView rvBook;
    BukuAdapter bukuAdapter;
    EditText editSearch;
    List<Buku> listBuku;
    List<Buku> searchBuku;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        preferences = BookActivity.this.getSharedPreferences("login_session", Context.MODE_PRIVATE);
        mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        mData = getIntent();

        initView();

        getListBook();
        searchBuku = new ArrayList<>();

        editSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.length() > 0) {
                    if(searchBuku.size() > 0) {
                        Log.d("cari", "kosongkan list pencarian");
                        searchBuku.clear();
                    }
                    // melakukan pencarian
                    Log.d("cari", s.toString());
                    for(Buku item:listBuku) {
                        String data = item.getNama().toLowerCase();
                        if(data.contains(s.toString().toLowerCase())) {
                            searchBuku.add(item);
                        }
                    }
                    bukuAdapter = new BukuAdapter(searchBuku, BookActivity.this);
                    rvBook.setAdapter(bukuAdapter);
                }
                else {
                    // jika kolom pencarian kosong
                    Log.d("cari", "kolom kosong");
                    getListBook();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        BookActivity.this.finish();
        return true;
    }

    private void initView() {
        rvBook = findViewById(R.id.rv_buku);
        rvBook.setLayoutManager(new LinearLayoutManager(BookActivity.this));

        editSearch = findViewById(R.id.src);
    }

    private void getListBook() {
        if(mData.getBooleanExtra("is_favorit", false)) {
            Call<GetBuku> callBook = mApiInterface.getFavorit(preferences.getInt("id_user", 0));
            callBook.enqueue(new Callback<GetBuku>() {
                @Override
                public void onResponse(Call<GetBuku> call, Response<GetBuku> response) {
                    try {
                        listBuku = response.body().getmBuku();
                        bukuAdapter = new BukuAdapter(listBuku, BookActivity.this);
                        rvBook.setAdapter(bukuAdapter);
                    }
                    catch (Exception e) {
                        Log.e("getListBook", e.getMessage());
                        Toast.makeText(BookActivity.this, "Terjadi Kesalahan", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<GetBuku> call, Throwable t) {
                    Log.e("getListBook", t.getMessage());
                    Toast.makeText(BookActivity.this, "Terjadi Kesalahan", Toast.LENGTH_SHORT).show();
                }
            });
        }
        else {
            Call<GetBuku> callBook = mApiInterface.getBookByKategori(mData.getStringExtra("kategori"));
            callBook.enqueue(new Callback<GetBuku>() {
                @Override
                public void onResponse(Call<GetBuku> call, Response<GetBuku> response) {
                    try {
                        listBuku = response.body().getmBuku();
                        bukuAdapter = new BukuAdapter(listBuku, BookActivity.this);
                        rvBook.setAdapter(bukuAdapter);
                    }
                    catch (Exception e) {
                        Log.e("getListBook", e.getMessage());
                        Toast.makeText(BookActivity.this, "Terjadi Kesalahan", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<GetBuku> call, Throwable t) {
                    Log.e("getListBook", t.getMessage());
                    Toast.makeText(BookActivity.this, "Terjadi Kesalahan", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}