package com.example.kataku.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.kataku.R;
import com.example.kataku.core.ApiClient;
import com.example.kataku.core.ApiInterface;
import com.example.kataku.model.CekIsFavorit;
import com.example.kataku.model.TambahHapusFavorit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailActivity extends AppCompatActivity {

    private ApiInterface mApiInterface;
    private SharedPreferences preferences;
    private Intent mData;
    private ImageView imgCover;
    private TextView tvJudul, tvKategori, tvBerat, tvDesc;
    private Button btnTambahFavorit, btnHapusFavorit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        preferences = DetailActivity.this.getSharedPreferences("login_session", Context.MODE_PRIVATE);
        mData = DetailActivity.this.getIntent();

        initView();

        setData();
        
        if(preferences.getBoolean("is_login", false)) {
            // ketika sudah login
            checkIsFavorit();
            btnHapusFavorit.setVisibility(View.GONE);
        }

        btnTambahFavorit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(preferences.getBoolean("is_login", false)) {
                    // ketika sudah login
                    tambahFavorit();
                }
                else {
                    // ketika belum login
                    Toast.makeText(DetailActivity.this, "Silahkan login terlebih dahulu", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnHapusFavorit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hapusFavorit();
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        DetailActivity.this.finish();
        return true;
    }

    private void initView() {
        imgCover = findViewById(R.id.img_buku);
        tvJudul = findViewById(R.id.judul_buku);
        tvKategori = findViewById(R.id.kategori_buku);
        tvBerat = findViewById(R.id.berat_buku);
        tvDesc = findViewById(R.id.deskripsi_buku);
        btnTambahFavorit = findViewById(R.id.btn_tambah);
        btnHapusFavorit = findViewById(R.id.btn_hapus);
    }

    private void setData() {
        String imgUrl = ApiClient.ASSET_URL + mData.getStringExtra("cover");
        Glide.with(DetailActivity.this).load(imgUrl).into(imgCover);

        tvJudul.setText(mData.getStringExtra("judul"));
        tvKategori.setText(mData.getStringExtra("kategori"));
        tvBerat.setText(mData.getIntExtra("berat", 0) + "g");
        tvDesc.setText(mData.getStringExtra("deskripsi"));
    }

    private void checkIsFavorit() {
        Call<CekIsFavorit> cekIsFavoritCall = mApiInterface.checkIsFavorit(mData.getIntExtra("id", 0), preferences.getInt("id_user", 0));
        cekIsFavoritCall.enqueue(new Callback<CekIsFavorit>() {
            @Override
            public void onResponse(Call<CekIsFavorit> call, Response<CekIsFavorit> response) {
                try {
                    if(response.body().getStatus().equals("sukses")) {
                        if(response.body().getMessage().equals("Favorit")) {
                            btnTambahFavorit.setVisibility(View.GONE);
                            btnHapusFavorit.setVisibility(View.VISIBLE);
                        }
                        if(response.body().getMessage().equals("Belum favorit")) {
                            btnTambahFavorit.setVisibility(View.VISIBLE);
                            btnHapusFavorit.setVisibility(View.GONE);
                        }
                    }
                }
                catch (Exception e) {
                    Log.e("checkIsFavorit", e.getMessage());
                    Toast.makeText(DetailActivity.this, "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CekIsFavorit> call, Throwable t) {
                Log.e("checkIsFavorit", t.getMessage());
                Toast.makeText(DetailActivity.this, "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void tambahFavorit() {
        Call<TambahHapusFavorit> tambahHapusFavoritCall = mApiInterface.tambahFavorit(mData.getIntExtra("id", 0), preferences.getInt("id_user", 0));
        tambahHapusFavoritCall.enqueue(new Callback<TambahHapusFavorit>() {
            @Override
            public void onResponse(Call<TambahHapusFavorit> call, Response<TambahHapusFavorit> response) {
                try {
                    if(response.body().getStatus().equals("sukses")) {
                        Toast.makeText(DetailActivity.this, "Berhasil menambah ke favorit", Toast.LENGTH_SHORT).show();
                        checkIsFavorit();
                    }
                    else {
                        Toast.makeText(DetailActivity.this, "Gagal menambah ke favorit", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception e) {
                    Log.e("tambahFavorit", e.getMessage());
                    Toast.makeText(DetailActivity.this, "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TambahHapusFavorit> call, Throwable t) {
                Log.e("tambahFavorit", t.getMessage());
                Toast.makeText(DetailActivity.this, "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void hapusFavorit() {
        Call<TambahHapusFavorit> hapusFavoritCall = mApiInterface.hapusFavorit(mData.getIntExtra("id", 0), preferences.getInt("id_user", 0));
        hapusFavoritCall.enqueue(new Callback<TambahHapusFavorit>() {
            @Override
            public void onResponse(Call<TambahHapusFavorit> call, Response<TambahHapusFavorit> response) {
                try {
                    if(response.body().getStatus().equals("sukses")) {
                        Toast.makeText(DetailActivity.this, "Berhasil menghapus dari favorit", Toast.LENGTH_SHORT).show();
                        checkIsFavorit();
                    }
                    else {
                        Toast.makeText(DetailActivity.this, "Gagal menghapus favorit", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception e) {
                    Log.e("hapusFavorit", e.getMessage());
                    Toast.makeText(DetailActivity.this, "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TambahHapusFavorit> call, Throwable t) {
                Log.e("hapusFavorit", t.getMessage());
                Toast.makeText(DetailActivity.this, "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
            }
        });
    }
}