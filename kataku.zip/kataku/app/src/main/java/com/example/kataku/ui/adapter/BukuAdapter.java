package com.example.kataku.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kataku.R;
import com.example.kataku.model.Buku;
import com.example.kataku.ui.activity.DetailActivity;

import java.util.List;

public class BukuAdapter extends RecyclerView.Adapter<BukuAdapter.MyViewHolder> {

    Context context;
    List<Buku> listBuku;
    
    public BukuAdapter(List<Buku> buku, Context context) {
        this.context = context;
        this.listBuku = buku;
    }
    
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_book,parent,false);
        BukuAdapter.MyViewHolder myViewHolder = new BukuAdapter.MyViewHolder(mView);
        return myViewHolder;
    }

    @Override
    public int getItemCount() {
        return listBuku.size();
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.tvTitle.setText(listBuku.get(position).getNama());
        holder.tvDeskripsi.setText(!listBuku.get(position).getDeskripsi().equals("") ? listBuku.get(position).getDeskripsi().substring(0, 79) + "..." : "-");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goDetail = new Intent(context, DetailActivity.class);
                goDetail.putExtra("id", listBuku.get(position).getId());
                goDetail.putExtra("judul", listBuku.get(position).getNama());
                goDetail.putExtra("kategori", listBuku.get(position).getKategori());
                goDetail.putExtra("berat", listBuku.get(position).getBerat());
                goDetail.putExtra("deskripsi", listBuku.get(position).getDeskripsi());
                goDetail.putExtra("cover", listBuku.get(position).getFoto());
                goDetail.putExtra("is_favorit", false);

                context.startActivity(goDetail);
            }
        });
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvTitle, tvDeskripsi;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTitle = itemView.findViewById(R.id.tv_judul);
            tvDeskripsi = itemView.findViewById(R.id.tv_deskripsi);
        }
    }
}
