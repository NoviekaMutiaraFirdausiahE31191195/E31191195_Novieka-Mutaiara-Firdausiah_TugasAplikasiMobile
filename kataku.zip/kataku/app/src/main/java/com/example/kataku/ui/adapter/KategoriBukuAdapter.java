package com.example.kataku.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kataku.R;
import com.example.kataku.model.KategoriBuku;
import com.example.kataku.ui.activity.BookActivity;

import java.util.List;

public class KategoriBukuAdapter extends RecyclerView.Adapter<KategoriBukuAdapter.MyViewHolder> {

    Context context;
    List<KategoriBuku> listKategori;
    
    public KategoriBukuAdapter(List<KategoriBuku> kategori, Context context) {
        this.context = context;
        this.listKategori = kategori;
    }
    
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_kategori,parent,false);
        KategoriBukuAdapter.MyViewHolder myViewHolder = new KategoriBukuAdapter.MyViewHolder(mView);
        return myViewHolder;
    }

    @Override
    public int getItemCount() {
        return listKategori.size();
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.tvTitle.setText(listKategori.get(position).getNama_kategori());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, BookActivity.class);
                intent.putExtra("kategori", listKategori.get(position).getNama_kategori());
                context.startActivity(intent);
//                Toast.makeText(context, listKategori.get(position).getNama_kategori(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView tvTitle;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTitle = itemView.findViewById(R.id.tv_judul_kategori);
        }
    }
}
