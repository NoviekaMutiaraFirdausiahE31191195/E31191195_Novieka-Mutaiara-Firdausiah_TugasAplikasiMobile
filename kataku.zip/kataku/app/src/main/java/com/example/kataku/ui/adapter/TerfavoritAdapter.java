package com.example.kataku.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kataku.R;
import com.example.kataku.model.Buku;
import com.example.kataku.ui.activity.DetailActivity;

import java.util.List;

public class TerfavoritAdapter extends RecyclerView.Adapter<TerfavoritAdapter.TerfavoritViewHolder> {

    Context context;
    List<Buku> mList;

    public TerfavoritAdapter(List<Buku> buku, Context context) {
        this.mList = buku;
        this.context = context;
    }

    @NonNull
    @Override
    public TerfavoritViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_favorit,parent,false);
        TerfavoritViewHolder myViewHolder = new TerfavoritViewHolder(mView);
        return myViewHolder;
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull TerfavoritViewHolder holder, final int position) {
        holder.tvJudul.setText(mList.get(position).getNama());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goDetail = new Intent(context, DetailActivity.class);
                goDetail.putExtra("id", mList.get(position).getId());
                goDetail.putExtra("judul", mList.get(position).getNama());
                goDetail.putExtra("kategori", mList.get(position).getKategori());
                goDetail.putExtra("berat", mList.get(position).getBerat());
                goDetail.putExtra("deskripsi", mList.get(position).getDeskripsi());
                goDetail.putExtra("cover", mList.get(position).getFoto());

                context.startActivity(goDetail);

//                Toast.makeText(context, String.valueOf(mList.get(position).getId()), Toast.LENGTH_SHORT).show();
            }
        });
    }

    class TerfavoritViewHolder extends RecyclerView.ViewHolder {

        TextView tvJudul;

        public TerfavoritViewHolder(@NonNull View itemView) {
            super(itemView);
            tvJudul = itemView.findViewById(R.id.tv_favorit);
        }
    }
}