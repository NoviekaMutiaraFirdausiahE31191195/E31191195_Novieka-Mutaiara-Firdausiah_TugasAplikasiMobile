package com.example.kataku.ui.fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kataku.R;
import com.example.kataku.core.ApiClient;
import com.example.kataku.core.ApiInterface;
import com.example.kataku.model.GetBuku;
import com.example.kataku.model.GetKategoriBuku;
import com.example.kataku.ui.adapter.KategoriBukuAdapter;
import com.example.kataku.ui.adapter.TerfavoritAdapter;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    private ApiInterface mApiInterface;
    RecyclerView rvFavorit, rvKategori;
    TerfavoritAdapter terfavoritAdapter;
    KategoriBukuAdapter kategoriAdapter;
    private TextView tvTerfavorit;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        initView(view);

        getTerfavorit();
        getKategori();
    }

    private void initView(View view) {
        this.tvTerfavorit = view.findViewById(R.id.tv1);
        this.rvFavorit = view.findViewById(R.id.rv_favorit);
        this.rvKategori = view.findViewById(R.id.rv_kategori);

        LinearLayoutManager layoutManager
                = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        this.rvFavorit.setLayoutManager(layoutManager);

        this.rvKategori.setLayoutManager(new LinearLayoutManager(getActivity()));
    }

    private void getTerfavorit() {
        Call<GetBuku> callBuku = mApiInterface.getTerfavorit();
        callBuku.enqueue(new Callback<GetBuku>() {
            @Override
            public void onResponse(Call<GetBuku> call, Response<GetBuku> response) {
                try {
                    if(response.body().getmBuku().size() > 0) {
                        // data ada
                        tvTerfavorit.setVisibility(View.VISIBLE);
                        rvFavorit.setVisibility(View.VISIBLE);
                        terfavoritAdapter = new TerfavoritAdapter(response.body().getmBuku(), getActivity());
                        rvFavorit.setAdapter(terfavoritAdapter);
                    }
                    else {
                        // data belum ada
                        tvTerfavorit.setVisibility(View.GONE);
                        rvFavorit.setVisibility(View.GONE);
                    }
                }
                catch (Exception e) {
                    Log.e("getTerfavorit", e.getMessage());
                    Toast.makeText(getActivity(), "Terjadi Kesalahan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GetBuku> call, Throwable t) {
                Log.e("getTerfavorit", t.getMessage());
                Toast.makeText(getActivity(), "Terjadi Kesalahan", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getKategori() {
        Call<GetKategoriBuku> callKategori = mApiInterface.getKategoriBuku();
        callKategori.enqueue(new Callback<GetKategoriBuku>() {
            @Override
            public void onResponse(Call<GetKategoriBuku> call, Response<GetKategoriBuku> response) {
                try {
                    kategoriAdapter = new KategoriBukuAdapter(response.body().getmKategori(), getActivity());
                    rvKategori.setAdapter(kategoriAdapter);
                }
                catch (Exception e) {
                    Log.e("getKategori", e.getMessage());
                    Toast.makeText(getActivity(), "Terjadi Kesalahan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GetKategoriBuku> call, Throwable t) {
                Log.e("getKategori", t.getMessage());
                Toast.makeText(getActivity(), "Terjadi Kesalahan", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
